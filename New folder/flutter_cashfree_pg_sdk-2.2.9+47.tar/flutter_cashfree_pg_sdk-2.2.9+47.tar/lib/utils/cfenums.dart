enum CFEnvironment {
  SANDBOX,
  PRODUCTION
}

enum CFPaymentModes{
  CARD,
  UPI,
  NETBANKING,
  WALLET,
  PAYLATER,
  EMI
}