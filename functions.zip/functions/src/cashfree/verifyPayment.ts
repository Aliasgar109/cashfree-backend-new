import * as functions from 'firebase-functions';

export const verifyCashfreePayment = functions.https.onRequest(async (req, res) => {
  // Enable CORS
  res.set('Access-Control-Allow-Origin', '*');
  res.set('Access-Control-Allow-Methods', 'GET, POST');
  res.set('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.status(204).send('');
    return;
  }

  try {
    const { order_id } = req.body;

    // Validate required fields
    if (!order_id) {
      res.status(400).json({ error: 'Order ID is required' });
      return;
    }

    // Get environment variables
    const CASHFREE_APP_ID = functions.config().cashfree?.app_id;
    const CASHFREE_SECRET_KEY = functions.config().cashfree?.secret_key;
    const CASHFREE_BASE_URL = functions.config().cashfree?.base_url || 'https://sandbox.cashfree.com/pg';

    if (!CASHFREE_APP_ID || !CASHFREE_SECRET_KEY) {
      res.status(500).json({ error: 'Cashfree credentials not configured' });
      return;
    }

    // Get order details from Cashfree
    const response = await fetch(`${CASHFREE_BASE_URL}/orders/${order_id}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'x-client-id': CASHFREE_APP_ID,
        'x-client-secret': CASHFREE_SECRET_KEY,
        'x-api-version': '2022-09-01'
      }
    });

    const result = await response.json();

    if (!response.ok) {
      console.error('Cashfree API Error:', result);
      res.status(response.status).json({
        error: 'Failed to verify payment',
        details: result.message || result.error_description || 'Unknown error'
      });
      return;
    }

    // Get payment details if order is paid
    let paymentDetails = null;
    if (result.order_status === 'PAID') {
      const paymentResponse = await fetch(`${CASHFREE_BASE_URL}/orders/${order_id}/payments`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'x-client-id': CASHFREE_APP_ID,
          'x-client-secret': CASHFREE_SECRET_KEY,
          'x-api-version': '2022-09-01'
        }
      });

      if (paymentResponse.ok) {
        const paymentResult = await paymentResponse.json();
        if (paymentResult.length > 0) {
          paymentDetails = paymentResult[0];
        }
      }
    }

    // Return success response
    res.status(200).json({
      success: true,
      order_id: result.order_id,
      order_status: result.order_status,
      order_amount: result.order_amount,
      payment_status: paymentDetails?.payment_status || null,
      cf_payment_id: paymentDetails?.cf_payment_id || null,
      payment_amount: paymentDetails?.payment_amount || null,
      payment_method: paymentDetails?.payment_method || null,
      bank_reference: paymentDetails?.bank_reference || null,
      payment_time: paymentDetails?.payment_time || null,
      failure_reason: paymentDetails?.failure_reason || null
    });

  } catch (error) {
    console.error('Function Error:', error);
    res.status(500).json({ error: 'Internal server error', details: error.message });
  }
});
