import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';
import * as crypto from 'crypto';

// Initialize Firebase Admin only once
if (!admin.apps.length) {
  admin.initializeApp();
}

export const cashfreeWebhook = functions.https.onRequest(async (req, res) => {
  // CORS headers
  res.set('Access-Control-Allow-Origin', '*');
  res.set('Access-Control-Allow-Methods', 'GET, POST');
  res.set('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.status(204).send('');
    return;
  }

  try {
    const webhookData = req.body as Record<string, any>;
    const signature = req.headers['x-webhook-signature'] as string | undefined;

    const webhookSecret = functions.config().cashfree?.webhook_secret;
    if (!webhookSecret) {
      console.error('Webhook secret not configured');
      res.status(500).json({ error: 'Webhook secret not configured' });
      return;
    }

    if (!signature) {
      res.status(400).json({ error: 'Missing webhook signature' });
      return;
    }

    // ✅ Validate signature using HMAC SHA256
    const payload = JSON.stringify(req.body);
    const hmac = crypto
      .createHmac('sha256', webhookSecret)
      .update(payload)
      .digest('base64');

    if (hmac !== signature) {
      console.error('Invalid webhook signature');
      res.status(401).json({ error: 'Invalid webhook signature' });
      return;
    }

    // Extract key fields
    const orderId = webhookData.order_id;
    const orderStatus = webhookData.order_status;
    const paymentStatus = webhookData.payment_status;

    if (!orderId) {
      res.status(400).json({ error: 'Order ID not found in webhook' });
      return;
    }

    const db = admin.firestore();

    const updateData: Record<string, unknown> = {
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      cashfreeOrderId: orderId,
      cashfreePaymentId: webhookData.cf_payment_id || null,
      paymentGateway: 'cashfree',
      gatewayResponse: webhookData,
    };

    if (orderStatus === 'PAID' && paymentStatus === 'SUCCESS') {
      updateData.status = 'APPROVED';
      updateData.approvedAt = admin.firestore.FieldValue.serverTimestamp();
      updateData.approvedBy = 'CASHFREE_WEBHOOK';
      updateData.transactionId = webhookData.cf_payment_id;
      updateData.paidAt = admin.firestore.FieldValue.serverTimestamp();
    } else if (orderStatus === 'EXPIRED' || paymentStatus === 'FAILED') {
      updateData.status = 'REJECTED';
      updateData.rejectionReason =
        webhookData.failure_reason || 'Payment failed';
    }

    // Update Firestore payments collection
    const paymentsRef = db.collection('payments');
    const query = paymentsRef.where('cashfreeOrderId', '==', orderId).limit(1);
    const snapshot = await query.get();

    if (!snapshot.empty) {
      const paymentDoc = snapshot.docs[0];
      await paymentDoc.ref.update(updateData);
    }

    console.log('✅ Webhook processed:', {
      orderId,
      orderStatus,
      paymentStatus,
      timestamp: new Date().toISOString(),
    });

    res.status(200).json({
      success: true,
      message: 'Webhook processed successfully',
      order_id: orderId,
      processed: true,
    });
  } catch (error) {
    console.error('Webhook Error:', error);
    const err = error as Error;
    res.status(500).json({
      error: 'Internal server error',
      details: err.message,
    });
  }
});
