import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';

// Initialize Firebase Admin
admin.initializeApp();

export const createCashfreeOrder = functions.https.onRequest(async (req, res) => {
  // Enable CORS
  res.set('Access-Control-Allow-Origin', '*');
  res.set('Access-Control-Allow-Methods', 'GET, POST');
  res.set('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.status(204).send('');
    return;
  }

  try {
    const { order_id, order_amount, customer_details, order_meta, payment_methods } = req.body;

    // Validate required fields
    if (!order_id || !order_amount || !customer_details) {
      res.status(400).json({ error: 'Missing required fields' });
      return;
    }

    // Get environment variables
    const CASHFREE_APP_ID = functions.config().cashfree?.app_id;
    const CASHFREE_SECRET_KEY = functions.config().cashfree?.secret_key;
    const CASHFREE_BASE_URL = functions.config().cashfree?.base_url || 'https://sandbox.cashfree.com/pg';

    if (!CASHFREE_APP_ID || !CASHFREE_SECRET_KEY) {
      res.status(500).json({ error: 'Cashfree credentials not configured' });
      return;
    }

    // Prepare order payload
    const orderPayload = {
      order_id: order_id,
      order_amount: order_amount,
      order_currency: "INR",
      customer_details: customer_details,
      order_meta: order_meta || {
        return_url: `${functions.config().app?.url || 'https://jafary-channel-1e3af.web.app'}/payment-return`,
        notify_url: `${functions.config().app?.url || 'https://jafary-channel-1e3af.web.app'}/cashfree-webhook`,
      },
      order_expiry_time: new Date(Date.now() + 30 * 60 * 1000).toISOString(),
      payment_methods: payment_methods || ["cc", "dc", "upi", "nb", "wallet"]
    };

    // Create order with Cashfree
    const response = await fetch(`${CASHFREE_BASE_URL}/orders`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-client-id': CASHFREE_APP_ID,
        'x-client-secret': CASHFREE_SECRET_KEY,
        'x-api-version': '2022-09-01'
      },
      body: JSON.stringify(orderPayload)
    });

    const result = await response.json();

    if (!response.ok) {
      console.error('Cashfree API Error:', result);
      res.status(response.status).json({
        error: 'Failed to create order',
        details: result.message || result.error_description || 'Unknown error'
      });
      return;
    }

    // Return success response
    res.status(200).json({
      success: true,
      payment_session_id: result.payment_session_id,
      order_status: result.order_status,
      order_id: result.order_id,
      order_amount: result.order_amount
    });

  } catch (error) {
    console.error('Function Error:', error);
    res.status(500).json({ error: 'Internal server error', details: error.message });
  }
});
