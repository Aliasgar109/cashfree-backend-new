package com.example.tv_subscription_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
